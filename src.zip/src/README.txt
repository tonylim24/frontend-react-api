2021-01-05:
Please subtract 20 minutes from my time due to dinner break at 7:03PM to 7:25PM.

On part 5, I have not implemented the search with tag function yet. 
I will resubmit another submission later on since I need to sleep for the night.

Update: 2021-01-07:
I have finished searching with tag also. It took me an additional 3 hours to solve it.
Thank you Hatchways, this assessment was fun!